## Simple ToDo application using React Redux and Firebase

![Preview](http://g.recordit.co/tMEezVSBwL.gif)

## Project Overview

This is a simple application for managing To Do tasks. Purpose of this application was to demonstrate how to combine Firebase with React and Redux
