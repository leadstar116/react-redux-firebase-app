export const FirebaseConfig = {
    apiKey: "AIzaSyA3jjfMyFwHqrXQYHHOVRl-EcHHiFk2KAY",
    authDomain: "test-12838.firebaseapp.com",
    databaseURL: "https://test-12838.firebaseio.com",
    projectId: "test-12838",
    storageBucket: "test-12838.appspot.com",
    messagingSenderId: "394403328110"
};
